<?php
session_start();

// Connexion à la base de données
$host = "localhost";
$user = "root";
$password = "";
$database = "Web";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier que le formulaire a été soumis
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_produit = intval($_POST['id_produit']);
    $quantite = intval($_POST['quantite']);

    // Vérifier que le produit existe et a assez de stock
    $query = "SELECT stock FROM produit WHERE id_produit = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id_produit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        die("Produit introuvable.");
    }
    
    $produit = $result->fetch_assoc();
    if ($produit['stock'] < $quantite) {
        die("Quantité non disponible.");
    }

    // Ajouter le produit au panier (table `Panier_Produit`)
    $id_client = $_SESSION['id_client'];
    $query = "
        INSERT INTO Panier_Produit (id_panier, id_produit, quantite)
        VALUES ((SELECT id_panier FROM Panier WHERE id_client = ? AND statut = 'en cours'), ?, ?)
        ON DUPLICATE KEY UPDATE quantite = quantite + VALUES(quantite)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iii", $id_client, $id_produit, $quantite);
    $stmt->execute();

    // Réduire le stock du produit
    $query = "UPDATE produit SET stock = stock - ? WHERE id_produit = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $quantite, $id_produit);
    $stmt->execute();

    // Redirection vers le panier
    header("Location: panier.php");
    exit;
}

$conn->close();
?>
