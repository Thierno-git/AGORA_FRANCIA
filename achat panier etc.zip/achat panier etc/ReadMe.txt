# Agora Francia - Documentation des fichiers

---

## **1. achat_direct.php**
- **Description :**
  - Affiche les détails d'un produit pour un achat direct.
- **Fonctionnalités :**
  - Affiche le nom, l'image, le prix, la description et le stock disponible.
  - Permet au client de sélectionner une quantité et d'ajouter le produit au panier.
- **Spécificité :**
  - Redirige vers `ajouter_au_panier.php` pour ajouter un produit.

---

## **2. ajouter_au_panier.php**
- **Description :**
  - Ajoute un produit sélectionné dans le panier du client.
- **Fonctionnalités :**
  - Vérifie que la quantité demandée est disponible.
  - Ajoute le produit au panier en mettant à jour la base de données.
  - Réduit le stock disponible pour le produit ajouté.
- **Spécificité :**
  - Supporte l'ajout multiple pour un même produit.

---

## **3. delete_article.php**
- **Description :**
  - Supprime un produit du panier.
- **Fonctionnalités :**
  - Supprime un produit spécifique pour le client connecté.
  - Redirige vers `panier.php` après la suppression.

---

## **4. panier.php**
- **Description :**
  - Affiche le contenu actuel du panier du client.
- **Fonctionnalités :**
  - Liste les produits avec image, nom, prix, quantité et sous-total.
  - Offre des actions pour modifier la quantité ou supprimer un produit.
  - Affiche le montant total du panier.
  - Bouton "Payer maintenant" redirige vers `payer.php`.
- **Spécificité :**
  - Gère automatiquement les mises à jour après modifications ou suppressions.

---

## **5. payer.php**
- **Description :**
  - Finalise le paiement des produits dans le panier.
- **Fonctionnalités :**
  - Affiche le résumé des produits avec le montant total.
  - Après confirmation :
    - Valide le panier.
    - Génère une facture avec le montant total.
    - Réduit le stock des produits achetés.
  - Redirige vers une page de confirmation.

---

## **6. modifier_quantite.php**
- **Description :**
  - Modifie la quantité d'un produit dans le panier.
- **Fonctionnalités :**
  - Met à jour la quantité pour un produit spécifique.
  - Vérifie que la quantité reste dans les limites du stock disponible.

---

## **7. enchere_produit.php**
- **Description :**
  - Gère les enchères pour un produit spécifique.
- **Fonctionnalités :**
  - Affiche les détails du produit en enchère (nom, description, prix initial, prix actuel, heure de fin).
  - Permet au client de soumettre une enchère (doit être supérieure au prix actuel).
  - Liste les enchères en cours.
- **Spécificité :**
  - Met à jour automatiquement le prix actuel après chaque enchère.

---

## **8. negociation_produit.php**
- **Description :**
  - Gère les négociations pour un produit spécifique.
- **Fonctionnalités :**
  - Affiche les détails du produit en négociation (nom, description, prix initial).
  - Permet au client de soumettre une proposition de prix.
  - Affiche l'historique des négociations pour ce produit.
- **Spécificité :**
  - Empêche les négociations si une offre a déjà été acceptée ou refusée.

---

## **9. supprimer_du_panier.php**
- **Description :**
  - Supprime un produit du panier pour un client connecté.
- **Fonctionnalités :**
  - Supprime le produit sélectionné et réajuste les données.

---

## Notes Importantes
1. **Gestion des Catégories :**
   - Les fichiers `enchere_produit.php` et `negociation_produit.php` s'appliquent uniquement aux produits dans les catégories correspondantes (`enchère` ou `négociation`).


Fin du README.
