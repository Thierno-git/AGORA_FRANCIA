<?php
session_start();

// Connexion à la base de données
$host = "localhost";
$user = "root";
$password = "";
$database = "Web";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier si le client est connecté
if (!isset($_SESSION['id_client'])) {
    header("Location: login_client.php");
    exit;
}

$id_client = $_SESSION['id_client'];

// Récupérer les produits du panier
$query = "
    SELECT 
        p.id_produit, 
        p.nom AS nom_produit, 
        p.prix, 
        p.image, 
        pp.quantite 
    FROM Panier_Produit pp
    INNER JOIN Panier pa ON pp.id_panier = pa.id_panier
    INNER JOIN produit p ON pp.id_produit = p.id_produit
    WHERE pa.id_client = ? AND pa.statut = 'en cours'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_client);
$stmt->execute();
$result = $stmt->get_result();
$produits = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $produits[] = $row;
    }
}

// Calculer le montant total
$total = 0;
foreach ($produits as $produit) {
    $total += $produit['prix'] * $produit['quantite'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panier - Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Agora Francia</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="tout_parcourir.php">Tout Parcourir</a></li>
                <li class="nav-item"><a class="nav-link active" href="panier.php">Panier</a></li>
                <li class="nav-item"><a class="nav-link" href="compte.php">Votre Compte</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h1 class="text-center">Votre Panier</h1>

    <?php if (count($produits) > 0): ?>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Produit</th>
                    <th>Prix Unitaire</th>
                    <th>Quantité</th>
                    <th>Sous-total</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produits as $produit): ?>
                    <tr>
                        <td>
                            <img src="<?php echo htmlspecialchars($produit['image']); ?>" alt="<?php echo htmlspecialchars($produit['nom_produit']); ?>" style="width: 50px; height: 50px; object-fit: cover;">
                            <?php echo htmlspecialchars($produit['nom_produit']); ?>
                        </td>
                        <td><?php echo htmlspecialchars($produit['prix']); ?> €</td>
                        <td>
                            <form action="modifier_quantite.php" method="POST" class="d-inline">
                                <input type="number" name="quantite" value="<?php echo htmlspecialchars($produit['quantite']); ?>" min="1" max="99" class="form-control form-control-sm" style="width: 70px; display: inline-block;">
                                <input type="hidden" name="id_produit" value="<?php echo htmlspecialchars($produit['id_produit']); ?>">
                                <button type="submit" class="btn btn-primary btn-sm">Modifier</button>
                            </form>
                        </td>
                        <td><?php echo htmlspecialchars($produit['prix'] * $produit['quantite']); ?> €</td>
                        <td>
                            <form action="supprimer_du_panier.php" method="POST" class="d-inline">
                                <input type="hidden" name="id_produit" value="<?php echo htmlspecialchars($produit['id_produit']); ?>">
                                <button type="submit" class="btn btn-danger btn-sm">Supprimer</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3 class="text-end">Total : <?php echo $total; ?> €</h3>

        <div class="text-end">
            <a href="payer.php" class="btn btn-success">Payer maintenant</a>
        </div>
    <?php else: ?>
        <p class="text-center">Votre panier est vide.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
