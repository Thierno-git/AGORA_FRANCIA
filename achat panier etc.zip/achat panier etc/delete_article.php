<?php
// Définir le type de contenu de la réponse comme JSON
header("Content-Type: application/json");

// Configuration de la connexion à la base de données
$host = "localhost";       // Nom d'hôte (par exemple localhost)
$db_name = "web";   // Nom de la base de données
$username = "root";        // Nom d'utilisateur
$password = "";            // Mot de passe

// Établir une connexion avec la base de données
$conn = new mysqli($host, $username, $password, $db_name);

// Vérifier si la connexion a échoué
if ($conn->connect_error) {
    echo json_encode(["message" => "Erreur de connexion à la base de données"]);
    http_response_code(500); // Erreur serveur
    exit;
}

// Lire les données JSON envoyées dans la requête
$data = json_decode(file_get_contents("php://input"), true);

// Vérifier si l'ID du produit est présent dans les données reçues
if (!isset($data['id_produit'])) {
    // Si l'ID est manquant, renvoyer un message d'erreur et un code de réponse 400
    echo json_encode(["message" => "ID du produit manquant"]);
    http_response_code(400); // Mauvaise requête
    exit;
}

$id_produit = $data['id_produit'];

// Préparer la requête SQL pour supprimer le produit
$sql = "DELETE FROM produit WHERE id_produit = ?" ;

if ($stmt = $conn->prepare($sql)) {
    // Associer l'ID du produit comme paramètre
    $stmt->bind_param("i", $id_produit);

    // Exécuter la requête
    if ($stmt->execute()) {
        // Vérifier si un produit a été supprimé
        if ($stmt->affected_rows > 0) {
            echo json_encode(["message" => "Produit supprimé avec succès"]);
            http_response_code(200); // Succès
        } else {
            echo json_encode(["message" => "Aucun produit trouvé avec cet ID"]);
            http_response_code(404); // Non trouvé
        }
    } else {
        echo json_encode(["message" => "Erreur lors de la suppression du produit"]);
        http_response_code(500); // Erreur serveur
    }

    // Fermer la déclaration
    $stmt->close();
} else {
    echo json_encode(["message" => "Erreur lors de la préparation de la requête"]);
    http_response_code(500); // Erreur serveur
}

// Fermer la connexion à la base de données
$conn->close();
