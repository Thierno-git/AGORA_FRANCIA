<?php
session_start();

// Vérification de la connexion client
if (!isset($_SESSION['id_client'])) {
    header('Location: login_client.php');
    exit;
}

// Connexion à la base de données
$host = 'localhost';
$dbname = 'Web';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erreur de connexion : " . $e->getMessage());
}

$id_client = $_SESSION['id_client'];
$id_produit = $_GET['id_produit'] ?? null;

if (!$id_produit) {
    die("Produit non spécifié.");
}

// Récupération des informations sur le produit
$queryProduit = "SELECT * FROM produit WHERE id_produit = :id_produit AND statut = 1";
$stmtProduit = $pdo->prepare($queryProduit);
$stmtProduit->execute(['id_produit' => $id_produit]);
$produit = $stmtProduit->fetch(PDO::FETCH_ASSOC);

if (!$produit) {
    die("Produit introuvable ou non disponible.");
}

// Récupération des propositions existantes pour ce produit et ce client
$queryNegociations = "SELECT * FROM negociation WHERE id_produit = :id_produit AND id_client = :id_client ORDER BY date_proposition DESC";
$stmtNegociations = $pdo->prepare($queryNegociations);
$stmtNegociations->execute([
    'id_produit' => $id_produit,
    'id_client' => $id_client,
]);
$negociations = $stmtNegociations->fetchAll(PDO::FETCH_ASSOC);

// Gestion du formulaire pour une nouvelle proposition
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prix_propose = (float) $_POST['prix_propose'];

    if ($prix_propose <= 0) {
        $erreur = "Veuillez entrer un prix valide.";
    } else {
        // Vérification du statut des négociations précédentes
        $statutNegociation = $negociations[0]['statut'] ?? null;
        if ($statutNegociation === 'accepte') {
            $erreur = "La négociation pour ce produit est déjà acceptée.";
        } elseif ($statutNegociation === 'Sans accord') {
            $erreur = "La négociation pour ce produit est déjà clôturée sans accord.";
        } else {
            // Ajout d'une nouvelle proposition
            $queryInsertNegociation = "INSERT INTO negociation (id_produit, id_client, prix_propose, tentative, date_proposition, statut) 
                                       VALUES (:id_produit, :id_client, :prix_propose, :tentative, NOW(), 'en_cours')";
            $stmtInsertNegociation = $pdo->prepare($queryInsertNegociation);
            $stmtInsertNegociation->execute([
                'id_produit' => $id_produit,
                'id_client' => $id_client,
                'prix_propose' => $prix_propose,
                'tentative' => count($negociations) + 1,
            ]);

            $message = "Votre proposition a été soumise avec succès.";
            header("Refresh:0"); // Recharge la page pour mettre à jour les propositions
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Négociation Produit - Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <header class="bg-dark text-white p-3">
        <div class="container">
            <h1>Négociation - <?= htmlspecialchars($produit['nom']); ?></h1>
        </div>
    </header>

    <main class="container mt-4">
        <?php if (isset($erreur)): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erreur); ?></div>
        <?php endif; ?>

        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?= htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <!-- Détails du produit -->
        <div class="card mb-4">
            <img src="<?= htmlspecialchars($produit['image']); ?>" class="card-img-top" alt="<?= htmlspecialchars($produit['nom']); ?>">
            <div class="card-body">
                <h5 class="card-title"><?= htmlspecialchars($produit['nom']); ?></h5>
                <p class="card-text"><?= htmlspecialchars($produit['description']); ?></p>
                <p class="card-text"><strong>Prix : <?= htmlspecialchars($produit['prix']); ?> €</strong></p>
                <p class="card-text"><strong>Stock : <?= htmlspecialchars($produit['stock']); ?></strong></p>
            </div>
        </div>

        <!-- Propositions existantes -->
        <h3>Vos propositions</h3>
        <?php if ($negociations): ?>
            <ul class="list-group mb-4">
                <?php foreach ($negociations as $negociation): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span>Proposition : <?= htmlspecialchars($negociation['prix_propose']); ?> €</span>
                        <span>Statut : <?= htmlspecialchars($negociation['statut']); ?></span>
                        <span>Date : <?= htmlspecialchars($negociation['date_proposition']); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>Aucune négociation en cours.</p>
        <?php endif; ?>

        <!-- Formulaire de nouvelle proposition -->
        <h3>Faire une nouvelle proposition</h3>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="prix_propose" class="form-label">Votre proposition (en €)</label>
                <input type="number" class="form-control" id="prix_propose" name="prix_propose" step="0.01" required>
            </div>
            <button type="submit" class="btn btn-primary">Soumettre</button>
        </form>
    </main>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
