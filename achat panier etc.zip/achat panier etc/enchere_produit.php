<?php
session_start();

// Connexion à la base de données
$host = "localhost";
$user = "root";
$password = "";
$database = "Web";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier si le client est connecté
if (!isset($_SESSION['id_client'])) {
    header("Location: login_client.php");
    exit;
}

$id_client = $_SESSION['id_client'];

// Vérifier si un produit spécifique est demandé
if (!isset($_GET['id_produit'])) {
    die("Produit non spécifié.");
}

$id_produit = intval($_GET['id_produit']);

// Récupérer les informations du produit
$query_produit = "
    SELECT 
        p.id_produit, 
        p.nom AS nom_produit, 
        p.description, 
        p.prix, 
        p.image, 
        e.prix_depart, 
        e.prix_max, 
        e.heure_fin 
    FROM produit p
    INNER JOIN enchere e ON p.id_produit = e.id_produit
    WHERE p.id_produit = ?";
$stmt_produit = $conn->prepare($query_produit);
$stmt_produit->bind_param("i", $id_produit);
$stmt_produit->execute();
$result_produit = $stmt_produit->get_result();
$produit = $result_produit->fetch_assoc();

if (!$produit) {
    die("Produit non trouvé.");
}

// Récupérer les enchères en cours pour ce produit
$query_encheres = "
    SELECT 
        pr.prix_propose, 
        c.nom AS client_nom, 
        pr.statut 
    FROM propositions pr
    INNER JOIN client c ON pr.id_client = c.id_client
    WHERE pr.id_enchere = (SELECT id_enchere FROM enchere WHERE id_produit = ?)
    ORDER BY pr.prix_propose DESC";
$stmt_encheres = $conn->prepare($query_encheres);
$stmt_encheres->bind_param("i", $id_produit);
$stmt_encheres->execute();
$result_encheres = $stmt_encheres->get_result();
$encheres = [];

if ($result_encheres->num_rows > 0) {
    while ($row = $result_encheres->fetch_assoc()) {
        $encheres[] = $row;
    }
}

// Gestion des enchères (soumission)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $prix_propose = floatval($_POST['prix_propose']);
    $heure_actuelle = date("Y-m-d H:i:s");

    // Vérifier que l'enchère est supérieure au prix actuel
    if ($prix_propose <= $produit['prix_max']) {
        $message_erreur = "Votre enchère doit être supérieure au prix actuel.";
    } else {
        // Insérer l'enchère dans la base de données
        $query_inserer_enchere = "
            INSERT INTO propositions (id_client, id_enchere, prix_propose, statut) 
            VALUES (?, (SELECT id_enchere FROM enchere WHERE id_produit = ?), ?, 'En attente')";
        $stmt_inserer = $conn->prepare($query_inserer_enchere);
        $stmt_inserer->bind_param("iid", $id_client, $id_produit, $prix_propose);
        $stmt_inserer->execute();

        // Mettre à jour le prix max de l'enchère
        $query_update_prix_max = "
            UPDATE enchere 
            SET prix_max = ? 
            WHERE id_produit = ?";
        $stmt_update_prix = $conn->prepare($query_update_prix_max);
        $stmt_update_prix->bind_param("di", $prix_propose, $id_produit);
        $stmt_update_prix->execute();

        header("Location: enchere_produit.php?id_produit=" . $id_produit);
        exit;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enchère - <?php echo htmlspecialchars($produit['nom_produit']); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Agora Francia</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="tout_parcourir.php">Tout Parcourir</a></li>
                <li class="nav-item"><a class="nav-link" href="panier.php">Panier</a></li>
                <li class="nav-item"><a class="nav-link" href="compte.php">Votre Compte</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Contenu principal -->
<div class="container mt-4">
    <h1 class="text-center">Enchère - <?php echo htmlspecialchars($produit['nom_produit']); ?></h1>

    <!-- Détails du produit -->
    <div class="card mb-4">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="<?php echo htmlspecialchars($produit['image']); ?>" class="img-fluid rounded-start" alt="<?php echo htmlspecialchars($produit['nom_produit']); ?>">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($produit['nom_produit']); ?></h5>
                    <p class="card-text"><?php echo htmlspecialchars($produit['description']); ?></p>
                    <p class="card-text">Prix de départ : <?php echo htmlspecialchars($produit['prix_depart']); ?> €</p>
                    <p class="card-text">Prix actuel : <?php echo htmlspecialchars($produit['prix_max']); ?> €</p>
                    <p class="card-text">Fin de l'enchère : <?php echo htmlspecialchars($produit['heure_fin']); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Formulaire pour placer une enchère -->
    <div class="mb-4">
        <h2>Placer une enchère</h2>
        <?php if (isset($message_erreur)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($message_erreur); ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="prix_propose" class="form-label">Votre enchère (€):</label>
                <input type="number" step="0.01" min="<?php echo $produit['prix_max'] + 1; ?>" class="form-control" id="prix_propose" name="prix_propose" required>
            </div>
            <button type="submit" class="btn btn-primary">Soumettre l'enchère</button>
        </form>
    </div>

    <!-- Liste des enchères en cours -->
    <div>
        <h2>Enchères en cours</h2>
        <ul class="list-group">
            <?php foreach ($encheres as $enchere): ?>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    <?php echo htmlspecialchars($enchere['client_nom']); ?> - <?php echo htmlspecialchars($enchere['prix_propose']); ?> €
                    <span class="badge bg-secondary"><?php echo htmlspecialchars($enchere['statut']); ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
