<?php
session_start();

// Connexion à la base de données
$host = "localhost";
$user = "root";
$password = "";
$database = "Web";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_client = $_SESSION['id_client'];
    $id_produit = intval($_POST['id_produit']);

    // Supprimer le produit du panier
    $query = "
        DELETE FROM Panier_Produit 
        WHERE id_panier = (SELECT id_panier FROM Panier WHERE id_client = ? AND statut = 'en cours') 
        AND id_produit = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $id_client, $id_produit);
    $stmt->execute();

    header("Location: panier.php");
    exit;
}

$conn->close();
?>
