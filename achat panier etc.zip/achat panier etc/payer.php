<?php
session_start();

// Connexion à la base de données
$host = "localhost";
$user = "root";
$password = "";
$database = "Web";
$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Vérifier si le client est connecté
if (!isset($_SESSION['id_client'])) {
    header("Location: login_client.php");
    exit;
}

$id_client = $_SESSION['id_client'];

// Récupérer les produits du panier
$query = "
    SELECT 
        p.id_produit, 
        p.nom AS nom_produit, 
        p.prix, 
        pp.quantite 
    FROM Panier_Produit pp
    INNER JOIN Panier pa ON pp.id_panier = pa.id_panier
    INNER JOIN produit p ON pp.id_produit = p.id_produit
    WHERE pa.id_client = ? AND pa.statut = 'en cours'";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id_client);
$stmt->execute();
$result = $stmt->get_result();
$produits = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $produits[] = $row;
    }
}

// Calculer le montant total
$total = 0;
foreach ($produits as $produit) {
    $total += $produit['prix'] * $produit['quantite'];
}

// Confirmer le paiement
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Mettre à jour le statut du panier à "validé"
    $query_update_panier = "
        UPDATE Panier 
        SET statut = 'validé', date_modification = NOW()
        WHERE id_client = ? AND statut = 'en cours'";
    $stmt_update = $conn->prepare($query_update_panier);
    $stmt_update->bind_param("i", $id_client);
    $stmt_update->execute();

    // Générer une facture
    $query_facture = "
        INSERT INTO Facture (id_panier, date_creation, montant_total) 
        VALUES ((SELECT id_panier FROM Panier WHERE id_client = ? AND statut = 'validé'), NOW(), ?)";
    $stmt_facture = $conn->prepare($query_facture);
    $stmt_facture->bind_param("id", $id_client, $total);
    $stmt_facture->execute();

    // Réduire le stock des produits
    foreach ($produits as $produit) {
        $query_stock = "
            UPDATE produit 
            SET stock = stock - ? 
            WHERE id_produit = ?";
        $stmt_stock = $conn->prepare($query_stock);
        $stmt_stock->bind_param("ii", $produit['quantite'], $produit['id_produit']);
        $stmt_stock->execute();
    }

    // Rediriger vers une page de confirmation
    header("Location: confirmation_paiement.php");
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payer Maintenant - Agora Francia</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Agora Francia</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link" href="tout_parcourir.php">Tout Parcourir</a></li>
                <li class="nav-item"><a class="nav-link active" href="panier.php">Panier</a></li>
                <li class="nav-item"><a class="nav-link" href="compte.php">Votre Compte</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mt-4">
    <h1 class="text-center">Finalisation du Paiement</h1>

    <?php if (count($produits) > 0): ?>
        <table class="table table-bordered mt-4">
            <thead>
                <tr>
                    <th>Produit</th>
                    <th>Prix Unitaire</th>
                    <th>Quantité</th>
                    <th>Sous-total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($produits as $produit): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($produit['nom_produit']); ?></td>
                        <td><?php echo htmlspecialchars($produit['prix']); ?> €</td>
                        <td><?php echo htmlspecialchars($produit['quantite']); ?></td>
                        <td><?php echo htmlspecialchars($produit['prix'] * $produit['quantite']); ?> €</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <h3 class="text-end">Total à payer : <?php echo $total; ?> €</h3>

        <form method="POST" class="text-end">
            <button type="submit" class="btn btn-success">Confirmer le paiement</button>
        </form>
    <?php else: ?>
        <p class="text-center">Votre panier est vide. Ajoutez des produits pour finaliser un achat.</p>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
